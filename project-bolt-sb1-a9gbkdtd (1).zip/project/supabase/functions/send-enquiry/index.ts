import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface EnquiryPayload {
  name: string;
  email: string;
  company?: string;
  role: string;
  salary?: string;
  urgency?: string;
  message?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const YOUR_EMAIL = Deno.env.get("ENQUIRY_EMAIL");
    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

    if (!YOUR_EMAIL) {
      throw new Error("ENQUIRY_EMAIL environment variable not set");
    }

    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY environment variable not set");
    }

    const payload: EnquiryPayload = await req.json();

    const emailBody = `
New Enquiry from Executive Search Website

Name: ${payload.name}
Email: ${payload.email}
Company: ${payload.company || "Not provided"}
Role: ${payload.role}
Salary: ${payload.salary || "Not provided"}
Urgency: ${payload.urgency || "Not provided"}

Message:
${payload.message || "No message provided"}
    `.trim();

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Executive Search <onboarding@resend.dev>",
        to: [YOUR_EMAIL],
        reply_to: payload.email,
        subject: `New Enquiry: ${payload.role} - ${payload.name}`,
        text: emailBody,
      }),
    });

    if (!emailResponse.ok) {
      const error = await emailResponse.text();
      console.error("Resend API error:", error);
      throw new Error(`Failed to send email: ${error}`);
    }

    const data = await emailResponse.json();

    return new Response(
      JSON.stringify({ success: true, messageId: data.id }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error sending enquiry:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
