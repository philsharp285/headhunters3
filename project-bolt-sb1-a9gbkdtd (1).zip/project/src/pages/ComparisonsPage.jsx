import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { C, COMPARISONS } from "../data";
import { BackBtn, SectionTitle, CalendlyBtn, GoldBtn } from "../components/Buttons";
import { EnquiryBox } from "../components/EnquiryForm";
import { createBreadcrumbSchema, injectSchema } from "../utils/schema";

export default function ComparisonsPage() {
  const navigate = useNavigate();

  useEffect(() => {
    document.title = "Headhunter vs Recruiter | Executive Search Comparison Guides";
    const cleanup = injectSchema(createBreadcrumbSchema([
      { name: "Home", url: "https://headhunters.co.uk" },
      { name: "Comparisons", url: "https://headhunters.co.uk/comparisons" }
    ]));
    return cleanup;
  }, []);

  return <div style={{padding:"60px 20px 80px",maxWidth:1100,margin:"0 auto"}}>
    <BackBtn label="Home" onClick={()=>navigate("/")}/>
    <h1 style={{fontSize:"clamp(28px,4vw,42px)",fontWeight:800,color:C.dark,textAlign:"center",margin:"0 0 16px"}}>Headhunter & Executive Search Comparisons</h1>
    <p style={{fontSize:15,color:C.tl,maxWidth:700,margin:"0 auto 40px",textAlign:"center"}}>
      Side-by-side comparisons to help you choose the right approach for senior executive hiring.
    </p>
    <div style={{display:"grid",gap:20}}>
      {COMPARISONS.map(c=><div key={c.id} onClick={()=>navigate(`/comparison/${c.id}`)} style={{background:C.card,border:`1px solid ${C.bd}`,borderRadius:8,padding:24,cursor:"pointer",transition:"all 0.2s",boxShadow:"0 1px 3px rgba(0,0,0,0.05)",display:"flex",gap:20,alignItems:"center"}} onMouseEnter={e=>{e.currentTarget.style.boxShadow="0 4px 12px rgba(0,0,0,0.1)";e.currentTarget.style.borderColor=C.accent;}} onMouseLeave={e=>{e.currentTarget.style.boxShadow="0 1px 3px rgba(0,0,0,0.05)";e.currentTarget.style.borderColor=C.bd;}}>
        <div style={{fontSize:40}}>{c.icon}</div>
        <div>
          <h3 style={{fontSize:20,fontWeight:700,color:C.tx,margin:"0 0 8px"}}>{c.title}</h3>
          <p style={{fontSize:14,color:C.tl,lineHeight:1.5,margin:0}}>{c.subtitle}</p>
        </div>
      </div>)}
    </div>
    <EnquiryBox
      title="Not sure which approach is right for you?"
      subtitle="Discuss your hiring needs with a specialist consultant"
      buttonText="Get Expert Advice"
      context="Enquiry from Comparisons page"
    />
    <div style={{marginTop:40,display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
      <CalendlyBtn>Book Free Consultation</CalendlyBtn>
      <GoldBtn onClick={()=>navigate("/contact")}>Brief a Headhunter</GoldBtn>
    </div>
  </div>;
}
